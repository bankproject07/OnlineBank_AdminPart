package com.cg.obs.controller;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;



@Controller
public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		// TODO Auto-generated constructor stub
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	//=================================================
	//		USER LOGIN
	//==================================================
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,@RequestParam("password") String password,Model model)
	{
		
		System.out.println("123 "+userId+" "+password);
		Users user=userService.getUser(userId);
		System.out.println("user "+user);
		if(user!=null)
		{
			
			
			if(password.equalsIgnoreCase(user.getLoginPassword()))
			{
				System.out.println("user login success");
				return "index";
			}
		
		
		}
		model.addAttribute("errMsg", "Login error");
			return "pages/ErrorPage";
		
	}
	
	//================================================
	//			ADMIN LOGIN
	//================================================
	
	@RequestMapping("Adminlogin")
	public String getAdminPage(@RequestParam("username") String username,@RequestParam("password") String pass,Model model)
	{
		if(username.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin") )
		 {
			System.out.println("login success");
			 return "adminIndex";
		 }
		else
		{
			System.out.println("Login failed");
			 model.addAttribute("errMsg", "Invalid UserName And Password");
			 return ".././AdminPage";
		}
	}
	//=============================================
	//			GET NEW ACCOUNT PAGE
	//=============================================
	@RequestMapping("NewAccount")
	public String getNewAccountPage(Model model)
	{

		List<String> accountType = new ArrayList<String>();
		accountType.add("Select");
		accountType.add("Saving Account");
		accountType.add("Current Account");
		
		model.addAttribute("Type",accountType);
		model.addAttribute("request",new RequestTable());
		return "pages/NewAccount";
	}
	
	
	
	
	//===================================================
	//			ACCOUNT REQUEST
	//==================================================
	@RequestMapping(value="processRegistration",method = RequestMethod.POST)
	public String addAccountRequest(@ModelAttribute("request") @Valid RequestTable reqTab ,BindingResult result ,Model model)
	{	
		int customerID = reqTab.getCustId();
		Customer customer = userService.getCustomerbyId(customerID);
	
		
		if(customer!=null)
		{
			int accId = -1;
			try
			{
				accId = userService.addRequest(reqTab);
			
				model.addAttribute("AccountID", accId);
				return "pages/SuccessReg";
			} 
			catch (UserException e)
			{
				model.addAttribute("errMsg","Unable To add New Account Creation Request "+ e.getMessage());
				return "pages/NewAccount";
			}
		}
		else
		{
			model.addAttribute("errMsg","Customer Id Doesn't Exist");
			return "pages/NewAccount";
		}
	}
	
	//======================================================================
	//				VIEW REQUEST IN ADMIN TABLE
	//======================================================================
	
	@RequestMapping("ViewRequest")
	public String getRequestPage(Model model)
	{
		List<RequestTable> requestTab = null;
		try
		{
			requestTab = userService.getAllRequest();
			model.addAttribute("request", requestTab);
		}
		catch (Exception e) 
		{
			model.addAttribute("errMsg","Unable to Retrieve Request .\n Reason :"+e.getMessage());
			return "pages/ViewRequestPage";
		}
		if(requestTab == null)
		{
			model.addAttribute("errMsg","No Request Found");
			return "pages/ViewRequestPage";
		}
		return "pages/ViewRequestPage";
	}
	
	//========================================================================
	//					CREATE NEW ACCOUNT PAGE
	//==========================================================================
	@RequestMapping("CreateAccount")
	public String getCreateAccountPage(@RequestParam("custId")int cust_Id , Model model)
	{
		
		RequestTable req = userService.getAccountId(cust_Id);
		model.addAttribute("Request", req);
	//	model.addAttribute("customer", customer);
		model.addAttribute("account",new AccountMaster());
	
		return "pages/CreateAccount";
	}
	
	//=========================================================================
	//						ADD ACCOUNT 
	//=========================================================================
	@RequestMapping(value="InsertAccount" , method=RequestMethod.POST)
	public String processToAddAcouct(@ModelAttribute("account")AccountMaster account, Model model)
	{
		try
		{
			System.out.println("adding account");
			userService.addUsers(account);
			int accid= (int) account.getAccountId();
			userService.deleteRequest(accid);
			
			return "pages/sucess";
		} 
		catch (UserException e)
		{
			//System.out.println(e.getMessage());
			model.addAttribute("errMsg",e.getMessage());
			return "pages/CreateAccount";
		}
		
	
	}
	
	//=============================================================================
	//						VIEW SERVICE REQUEST
	//=============================================================================
	
	@RequestMapping("ViewService")
	public String getServiceRequest(Model model)
	{
		List<ServiceTracker> service = null;
		try 
		{
			service = userService.getAllService();
			model.addAttribute("Service", service);
		} 
		catch (UserException e) 
		{
			model.addAttribute("errMsg","Unable to Retrieve Service Request .\n Reason :"+e.getMessage());
			return "pages/ViewServicePage";
		}
		if(service == null)
		{
			model.addAttribute("errMsg","No Records Found");
			return "pages/ViewServicePage";
		}
		return "pages/ViewServicePage";
	}
	
	//===============================================
	//
	//=================================================
	
	@RequestMapping("UpdateRequest")
	public String processUpdate(@RequestParam("serviceId") int serviceId,Model model)
	{
		ServiceTracker service= null;
		service = userService.getService(serviceId);
		String getstatus = service.getService_Status();
		System.out.println(getstatus);
		
		//update
		
		service.setService_Status("Cleared");
		userService.updateServiceStatus(service);
		model.addAttribute("Success","Service Request Cleared");
		return "pages/UpdateSuccess";
	}
	
	//=========================================================================
	//				TRANSACTION
	//=========================================================================
	


	
	
	@RequestMapping("Daily")
	public String processDailyTransaction(@RequestParam("date") Date date,Model model)
	{
		List<Transactions> dtlist=new ArrayList<Transactions>();
		try
		{
			dtlist=userService.viewDailyReport(date);
			model.addAttribute("DTlist",dtlist);
			return "pages/DailyTransactions";
		}
		catch(UserException e)
		{
			model.addAttribute("errMsg","No record Found :"+e.getMessage());
			return "pages/DailyTransactions";
		}
		
		
	}
	
	
	@RequestMapping(value="Monthly",method=RequestMethod.POST)
	public String processMonthly(@RequestParam("sdate") Date StartDate,@RequestParam("edate") Date EndDate,Model model)
	{
		List<Transactions> mtlist=null;
		
		try
		{
			mtlist=new ArrayList<>();
			mtlist=userService.viewMonthlyReport(StartDate, EndDate);
			model.addAttribute("MTlist",mtlist);
		}
		catch(UserException e)
		{
			model.addAttribute("errMsg","No record Found :"+e.getMessage());
			return "pages/MonthlyTransactions";
		}
		return "pages/MonthlyTransactions";
	}
	
	
	@RequestMapping("Yearly")
	public String processYearly(@RequestParam("sdate") Date StartDate,@RequestParam("edate") Date EndDate,Model model)
	{
		List<Transactions>ytlist=null;
		
		try
		{
			ytlist=userService.viewYearlyReport(StartDate, EndDate);
			model.addAttribute("YTlist",ytlist);
		}
		catch(UserException e)
		{
			model.addAttribute("errMsg","No record Found :"+e.getMessage());
			return "pages/YearlyTransactions";
		}
		return "pages/YearlyTransactions";
	}
	
	
			
}











