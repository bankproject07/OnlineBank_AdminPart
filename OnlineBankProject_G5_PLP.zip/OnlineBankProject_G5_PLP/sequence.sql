create sequence seq_fundtransfer_id start with 1000 increment by 1;

create sequence accountId_seq start with 12001200 increment by 1;

create sequence custId_seq start with 1500200 increment by 1;

create sequence seq_service_num  start with 12000 increment by 1;

create sequence seq_transactionid  start with 130010 increment by 1;

============================================================================

select accountId_seq.nextVal from dual;

select seq_service_num.nextVal from dual;



select * from USER_TABLE;
select  * from ACCOUNT_MASTER;
select * from customer1;
select * from REQUESTTABLE;

select * from Service_Tracker;
select * from transaction;


===================================================================================
delete from REQUESTTABLE;
drop sequence accId_seq;

==================================================================================


insert into USER_TABLE values(123456,12001215,123,'hg','hgf',789,'U');

insert into account_master values(accid_seq.nextVal,1500249,'Saving',1500,'01-apr-2017');

insert into Customer1 values(custId_seq.nextVal,'Subbu','subbu@gmamil.com',9856321470,'Kalyan','A123456');
insert into Customer1 values(custId_seq.nextVal,'Raji','raji@gmamil.com',9856321470,'Dadfar','A563456');

insert into Service_Tracker values(seq_service_num.nextVal,'ghjg',12001156,'04-apr-2017','processing');

================================================================================

insert into Transaction values (seq_transactionid.nextVal,'success','4-apr-2017','c',1000,12001215);

insert into Transaction values (seq_transactionid.nextVal,'success','1-mar-2017','d',1000,12001215);

insert into Transaction values (seq_transactionid.nextVal,'success','31-mar-2017','c',1000,12001156);

insert into Transaction values (seq_transactionid.nextVal,'success','1-jan-2016','c',1000,12001156);

insert into Transaction values (seq_transactionid.nextVal,'success','31-dec-2016','c',1000,12001215);